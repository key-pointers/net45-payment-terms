<?php

declare(strict_types=1);

namespace KeyPointers\Net45\Model\Payment;

/**
 * Net45 Terms Payment
 */
class Net45
{
    const METHOD_CODE = 'keypointers_net45';
}
